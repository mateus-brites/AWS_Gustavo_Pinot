'use strict';

module.exports.hello =  async function(event, context) {
  const requestBody = JSON.parse(event.body);
  const fullname = requestBody.fullname;
  const message = {message: `Hello Word! My name is ${fullname}`}
    console.log(message)

  const response = {
    statusCode: 200,
    body: JSON.stringify(message),
  };

  return response
  }
